</div><!-- pandel body End -->
		<div class="panel-footer"><!-- pandel footer start -->
			<span><a href="http://signaturesoftit.com">www.signaturesoftit.com</a></span>
		</div><!-- pandel body end -->
	</div><!-- pandel default -->
</div><!-- container end -->
</body>
</html>