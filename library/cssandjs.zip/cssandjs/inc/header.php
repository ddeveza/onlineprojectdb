<?php include 'config/config.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title>Tutorial</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/dataTables.min.css">
	<link rel="stylesheet" href="css/jquery-ui.css">
	<link rel="stylesheet" media="screen" href="css/main-clock.css"/>

	<script src="js/google.jquery.js"></script>
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/jquery-1.12.4.js"></script>
	<script src="js/jquery-ui.js"></script>
	<script src="js/font-awesome.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/dataTables.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/jquery.thooClock.js"></script> 
</head>
<body>
	<div class="container-fluid">
	<br>
	<div class="panel panel-primary">
		<div class="panel-heading">
			<span>Signature Soft IT</span>
		</div>

		<div style="min-height: 400px;" class="panel-body"><!-- pandel body start -->